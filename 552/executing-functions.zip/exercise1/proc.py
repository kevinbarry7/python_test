"""  
A procedure to roll two dice

Author: YOUR NAME HERE
Date: THE DATE HERE
"""
import random
