"""
A module with a fruitful function definition

Author: Walker M. White (wmw2)
Date:   February 14, 2019
"""

def plus(n):
    """
    Returns n+1
    """
    x = n+1
    return x
